#include <iostream>
#include "message.h"

using namespace std;

void message::printMessage(){
		cout << "Second New Makefile example\n";
}
