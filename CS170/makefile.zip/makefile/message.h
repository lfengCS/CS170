#ifndef MESSAGE_H
#define MESSAGE_H

class message{
	
public:
		void printMessage();
};

#endif // MESSAGE_H
